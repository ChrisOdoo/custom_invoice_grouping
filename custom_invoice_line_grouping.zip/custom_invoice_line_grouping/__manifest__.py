{
    'name': 'Consolidacion de multiples lineas de multiples ordenes a factura',
    'version': '1.0',
    'category': 'Accounting',
    'summary': 'Modulo para realizar la consolidacion de productos en vista de fcatura, para que si hay varios productos iguales solo muestre una linea.',
    'author': 'Ing. Christian Padilla',
    'depends': ['account'],
    'data': [
        
    ],
    'installable': True,
    'application': False,
}
