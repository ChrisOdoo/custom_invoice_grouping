from odoo import models, api

class AccountMove(models.Model):
    _inherit = 'account.move'

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if 'invoice_line_ids' in vals:
                lines = [line[2] for line in vals['invoice_line_ids'] if line[0] == 0 and line[2]]
                grouped = {}
                for line in lines:
                    # agrupamos por producto + precio unitario + impuestos
                    key = (
                        line.get('product_id'),
                        float(line.get('price_unit', 0.0)),
                        tuple(sorted(line.get('tax_ids', [])[0][2])) if line.get('tax_ids') else ()
                    )
                    if key not in grouped:
                        grouped[key] = line.copy()
                    else:
                        grouped[key]['quantity'] += line.get('quantity', 0.0)
                        grouped[key]['price_subtotal'] = grouped[key].get('price_subtotal', 0.0) + line.get('price_subtotal', 0.0)
                # reemplazamos las líneas originales con las agrupadas
                vals['invoice_line_ids'] = [(0, 0, line) for line in grouped.values()]
        return super().create(vals_list)
